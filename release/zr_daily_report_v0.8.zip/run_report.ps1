# ZR Daily Report 启动脚本
.\venv\Scripts\Activate.ps1
Set-Location -Path "zr_daily_report"
python zr_daily_report.py
