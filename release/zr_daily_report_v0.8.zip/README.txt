# ZR Daily Report Portable Package

This is a complete portable package containing all files needed to run ZR Daily Report.

## Installation Steps

1. Ensure Python 3.8 or higher is installed on the target computer
2. Double-click `install.bat` to run the installation script
3. Follow the prompts to complete environment setup

## Running the Program

After installation is complete, you can run the program by:
- Double-clicking `run_report.bat`
- Or executing `python zr_daily_report/zr_daily_report.py` in command line

## Package Structure
- `zr_daily_report/` - Main project directory
- `venv/` - Virtual environment directory (created after installation)
- `install.bat` - Installation script
- `run_report.bat` - Launch script

## System Requirements
- Windows 7/8/10/11
- Python 3.8 or higher
- At least 100MB of free disk space

## Notes
- Do not modify the directory structure
- To reinstall, delete the `venv` directory and run `install.bat` again
- If installation issues occur, check network connectivity or firewall settings
